from django.apps import AppConfig


class DjangoAppPermissionsConfig(AppConfig):
    name = 'django_app_permissions'
